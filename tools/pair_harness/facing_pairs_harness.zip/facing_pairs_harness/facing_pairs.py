"""facing_pairs.py -- the facing-pair (fusion-site) instrument from villa issue #191.

WHAT IT DOES
------------
Given a labelled sheet volume and one or more probability maps over the same
grid, it finds places where two *distinct* label sheets pass close to each other,
walks the straight line between the two facing surface voxels, and records the
shape of each probability map along that line.

The question it answers, per site and per model: does the model resolve the two
sheets as two peaks with a dip between them, or does it smear them into one?

Site definition pipeline (deterministic):
  1. reflect-pair candidates from the EDT nearest-index field. For a background
     voxel g, p1 = nearest label voxel. Reflect: q = 2g - p1. p2 = nearest label
     voxel to q. Keep when the two rays from g point in opposing directions,
     cos(v1, v2) < -0.3, where v1 = p1 - g and v2 = p2 - g. Deduplicate on the
     unordered (p1, p2) pair.
  2. clean interior: no label voxel strictly between p1 and p2 along the segment.
  3. local two-sheet guard: p1 and p2 must lie in DIFFERENT 26-connected
     components of the label volume, computed inside a window of radius
     max(4, ceil(1.5 * d12)) centred on the midpoint. Rejection counts per d12
     bin are logged -- this is where labels that merge tight contacts get caught.
  4. spatial thinning: greedy on midpoints, keep only sites >= min_sep voxels
     apart (3.0 tight / 4.0 loose), lexicographic order, deterministic.
  5. seeded cap: at most 300 tight / 100 loose sites per case.

Per site, per probability map, along the profile from s = -1.0 to s = d12 + 1.0
sampled every 0.25 voxels (trilinear):
    e1   max within 0.75 voxels of the p1 end      ("peak height at end 1")
    e2   max within 0.75 voxels of the p2 end      ("peak height at end 2")
    dip  min over the gap interior                 (margin-inset, see site_stats)
    mx   max over the whole profile
    pk4 / pk5 / pk6   number of local peaks with height >= t and prominence
                      >= 0.05, for t = 0.4 / 0.5 / 0.6.

  NOTE on the peak counts: there is a plateau fallback. If find_peaks returns 0
  peaks but the profile maximum is >= t, the count is recorded as 1, not 0. A
  profile that sits flat above t has no local maximum in the find_peaks sense but
  is plainly "one blob", and scoring it as zero peaks would be wrong. This is a
  real behaviour of the instrument, applied identically to every model, and it is
  called out here because it is easy to miss when reimplementing.

READOUT. At threshold t a site is
    detected = (e1 >= t) and (e2 >= t)      both sheet crossings supra-threshold
    fused    = detected and (dip >= t)      no sub-threshold dip -> ONE peak
    split    = detected and (dip <  t)      dip drops below t   -> TWO peaks
and the headline number is fused / detected.

CONTROLS
  --loose is on by default: a distance null of pairs at d12 in [8, 14] voxels,
                  which are too far apart to fuse. Fusion should collapse there.
                  If it does not, the measurement is picking up something other
                  than sheet separation. Disable with --no-loose.
  --mismatch      (batch mode) re-evaluate each case's tight-site coordinates on
                  the PREVIOUS case's probability maps. A shuffle null: geometry
                  from case i, probabilities from case i-1. The first case has no
                  value and its x* columns are blank.
  --gt-instance   optional ground-truth instance-label volume. When supplied, each
                  site additionally records the two GT instance ids at p1/p2 and
                  whether they differ. This scores the step-3 CC guard against
                  known truth and is the reason this file was packaged.
  --log-rejected  additionally write facing_pairs_cc_rejected.csv: every pair
                  that survived steps 1-2 but was REJECTED by the step-3 CC
                  guard (with GT ids when --gt-instance is given). Off by
                  default; does not change the two standard outputs. This is
                  what lets a holder of exact instance truth score the step-3
                  rejections pair by pair instead of only via the binned counts.

INPUTS
  A label volume (any integer/bool 3-D array; nonzero = sheet) and one or more
  probability maps of identical shape with values in [0, 1]. Accepted as .npy,
  or as keys inside a .npz. See --help and README.md.

OUTPUTS
  <out>/facing_pairs_sites.csv        one row per facing pair
  <out>/facing_pairs_case_diag.csv    per-case funnel, incl. the per-gap-bin
                                      survival counts through the CC guard
  <out>/facing_pairs_cc_rejected.csv  (only with --log-rejected) one row per
                                      step-3-rejected pair

PROVENANCE
  Ported from experiments/trackA/panel/fusion/extract_fusion_sites.py, the script
  that produced the Dataset059 numbers quoted in villa issue #191. The porting
  changes were: removal of hard-coded paths and model names, generalisation from
  cubic-only to arbitrary shapes (see README "Porting notes" -- the original
  compared all three axes against shape[0]), and the optional --gt-instance
  column. On a cubic volume with the same inputs this file reproduces the
  original's output rows exactly; that equivalence is checked by
  verify_against_original.py.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import sys
import time

import numpy as np
from scipy import ndimage as ndi
from scipy.signal import find_peaks

# ---------------------------------------------------------------- constants --
STEP = 0.25        # profile sampling step, voxels
EXT = 1.0          # profile extension beyond each endpoint, voxels
BORDER = 5         # voxels excluded at the volume boundary
PEAK_PROM = 0.05   # find_peaks prominence
PEAK_T = (0.4, 0.5, 0.6)
MAX_TIGHT = 300
MAX_LOOSE = 100
SAFETY_CAP = 60000            # cap on raw candidates before per-pair checks
BINS = [2, 3, 4, 5, 6.01]     # tight d12 bins for the rejection log
ST26 = ndi.generate_binary_structure(3, 3)

# (edt_lo, edt_hi, d12_min, d12_max, cap, min_sep)
TIGHT = (0.9, 3.05, 2.0, 6.0, MAX_TIGHT, 3.0)
LOOSE = (3.9, 7.05, 8.0, 14.0, MAX_LOOSE, 4.0)


# ------------------------------------------------------------------- stages --
def candidate_pairs(lbl, edt, inds, edtlo, edthi, dmin, dmax, border=BORDER):
    """Stage 1: reflect-pair candidates from the EDT nearest-index field."""
    shape = np.array(lbl.shape)
    bg = ~lbl
    cand = bg & (edt >= edtlo) & (edt <= edthi)
    cand[:border] = cand[-border:] = False
    cand[:, :border] = cand[:, -border:] = False
    cand[:, :, :border] = cand[:, :, -border:] = False
    g = np.argwhere(cand)
    empty = (np.zeros((0, 3), np.int64), np.zeros((0, 3), np.int64), np.zeros(0))
    if len(g) == 0:
        return empty

    p1 = inds[:, g[:, 0], g[:, 1], g[:, 2]].T.astype(np.int64)
    q = 2 * g - p1
    # per-axis bounds (the original compared every axis against shape[0])
    ok = np.all((q >= 0) & (q < shape[None, :]), axis=1)
    g, p1, q = g[ok], p1[ok], q[ok]
    if len(g) == 0:
        return empty
    p2 = inds[:, q[:, 0], q[:, 1], q[:, 2]].T.astype(np.int64)

    d12 = np.linalg.norm((p2 - p1).astype(float), axis=1)
    v1 = (p1 - g).astype(float)
    v2 = (p2 - g).astype(float)
    n1 = np.linalg.norm(v1, axis=1)
    n2 = np.linalg.norm(v2, axis=1)
    cos = (v1 * v2).sum(1) / np.maximum(n1 * n2, 1e-9)
    ok = (d12 >= dmin) & (d12 <= dmax) & (cos < -0.3)
    p1, p2, d12 = p1[ok], p2[ok], d12[ok]
    if len(p1) == 0:
        return empty

    ok = (np.all((p1 >= border) & (p1 < shape[None, :] - border), axis=1) &
          np.all((p2 >= border) & (p2 < shape[None, :] - border), axis=1))
    p1, p2, d12 = p1[ok], p2[ok], d12[ok]
    if len(p1) == 0:
        return empty

    # dedup on the unordered pair. Multiplier must be >= number of voxels.
    n = int(lbl.size)
    f1 = np.ravel_multi_index(p1.T, lbl.shape)
    f2 = np.ravel_multi_index(p2.T, lbl.shape)
    key = np.minimum(f1, f2) * n + np.maximum(f1, f2)
    _, idx = np.unique(key, return_index=True)
    idx = np.sort(idx)
    return p1[idx], p2[idx], d12[idx]


def build_profiles(P1, P2, D12, step=STEP, ext=EXT):
    """Sample coordinates along each p1->p2 segment, extended by `ext` each end."""
    coords, slices, dists = [], [], []
    off = 0
    for a, b, d in zip(P1, P2, D12):
        u = (b - a) / d
        s = np.arange(-ext, d + ext + 1e-9, step)
        coords.append(a[None, :] + s[:, None] * u[None, :])
        slices.append((off, off + len(s)))
        dists.append(s)
        off += len(s)
    return np.concatenate(coords).T, slices, dists


def clean_interior_mask(lbl, P1, P2, D12):
    """Stage 2: reject pairs with any label voxel strictly between the sheets."""
    coords, slices, dists = build_profiles(P1.astype(float), P2.astype(float), D12)
    lprof = ndi.map_coordinates(lbl.astype(np.float32), coords, order=0)
    keep = np.zeros(len(P1), bool)
    for i, ((a, b), s, d) in enumerate(zip(slices, dists, D12)):
        interior = (s >= 0.75) & (s <= d - 0.75)
        keep[i] = (not interior.any()) or lprof[a:b][interior].max() == 0
    return keep


def local_two_sheet_mask(lbl, P1, P2, D12):
    """Stage 3: p1 and p2 must be in different 26-connected components locally."""
    shape = np.array(lbl.shape)
    keep = np.zeros(len(P1), bool)
    for i in range(len(P1)):
        R = int(max(4, np.ceil(1.5 * D12[i])))
        m = ((P1[i] + P2[i]) / 2).round().astype(int)
        lo = np.maximum(m - R, 0)
        hi = np.minimum(m + R + 1, shape)
        cc, _ = ndi.label(lbl[lo[0]:hi[0], lo[1]:hi[1], lo[2]:hi[2]], structure=ST26)
        a = cc[tuple(P1[i] - lo)]
        b = cc[tuple(P2[i] - lo)]
        keep[i] = (a != b) and a > 0 and b > 0
    return keep


def thin_spatial(P1, P2, min_sep):
    """Stage 4: greedy thinning on midpoints, deterministic (lexicographic)."""
    M = (P1 + P2) / 2.0
    order = np.lexsort((M[:, 2], M[:, 1], M[:, 0]))
    kept, kept_pts = [], []
    for i in order:
        p = M[i]
        if all(np.linalg.norm(p - q) >= min_sep for q in kept_pts):
            kept.append(i)
            kept_pts.append(p)
    if not kept:
        return np.zeros(0, int)
    return np.sort(np.array(kept, int))


def site_stats(prof, s, d12):
    """End heights, interior dip, profile max, and peak counts at 0.4/0.5/0.6."""
    margin = min(1.0, max(0.6, (d12 - 0.5) / 2.0))
    m1 = s <= 0.75
    m2 = s >= d12 - 0.75
    mi = (s >= margin) & (s <= d12 - margin)
    e1 = float(prof[m1].max())
    e2 = float(prof[m2].max())
    dip = float(prof[mi].min()) if mi.any() else float(min(e1, e2))
    mx = float(prof.max())
    pks = []
    for t in PEAK_T:
        p, _ = find_peaks(prof, height=t, prominence=PEAK_PROM)
        n = len(p)
        if n == 0 and mx >= t:
            n = 1        # broad plateau above t with no interior structure
        pks.append(n)
    return e1, e2, dip, mx, pks


def _end_dip(prof, s, d12):
    """e1/e2/dip only -- used for the mismatch control columns."""
    margin = min(1.0, max(0.6, (d12 - 0.5) / 2.0))
    mi = (s >= margin) & (s <= d12 - margin)
    e1 = float(prof[s <= 0.75].max())
    e2 = float(prof[s >= d12 - 0.75].max())
    dip = float(prof[mi].min()) if mi.any() else min(e1, e2)
    return e1, e2, dip


# --------------------------------------------------------------- per-case ----
def make_rng(seed, case_index, case_id, seed_mode):
    if seed_mode == "index":
        return np.random.default_rng([seed, case_index])
    h = int(hashlib.sha256(case_id.encode("utf-8")).hexdigest()[:16], 16)
    return np.random.default_rng([seed, h])


def process_case(label, probs, *, case_id, model_names, rng,
                 do_loose=True, prev_probs=None, gt_instance=None,
                 max_tight=MAX_TIGHT, max_loose=MAX_LOOSE, log_rejected=False):
    """Run the full pipeline on one case.

    label        3-D array, nonzero = sheet
    probs        dict name -> 3-D float array in [0,1], same shape as label
    prev_probs   dict for the mismatch control, or None
    gt_instance  optional 3-D integer array of ground-truth sheet ids
    log_rejected also collect the pairs the step-3 CC guard rejected

    Returns (rows, diag, rejected): rows matches header_columns(); rejected
    matches rejected_columns() and is [] unless log_rejected.
    """
    lbl = np.asarray(label) > 0
    if lbl.ndim != 3:
        raise ValueError(f"label must be 3-D, got shape {lbl.shape}")
    for m in model_names:
        if m not in probs:
            raise ValueError(f"probability map '{m}' missing for case '{case_id}'")
        if probs[m].shape != lbl.shape:
            raise ValueError(
                f"prob '{m}' shape {probs[m].shape} != label shape {lbl.shape}")
    if gt_instance is not None and gt_instance.shape != lbl.shape:
        raise ValueError("gt_instance shape != label shape")
    if min(lbl.shape) <= 2 * BORDER:
        raise ValueError(
            f"volume {lbl.shape} too small: every axis must exceed 2*BORDER={2 * BORDER}")

    edt, inds = ndi.distance_transform_edt(~lbl, return_indices=True)
    nb = len(BINS) - 1
    diag = {"raw": 0, "clean": np.zeros(nb, int), "ccpass": np.zeros(nb, int),
            "tight": 0, "loose": 0}
    rows = []
    rejected = []

    stages = [("tight", TIGHT)]
    if do_loose:
        stages.append(("loose", LOOSE))
    caps = {"tight": max_tight, "loose": max_loose}

    for stype, (elo, ehi, dmin, dmax, _defcap, sep) in stages:
        cap = caps[stype]
        P1, P2, D12 = candidate_pairs(lbl, edt, inds, elo, ehi, dmin, dmax)
        if stype == "tight":
            diag["raw"] = len(P1)
        if len(P1) == 0:
            continue
        if len(P1) > SAFETY_CAP:
            sel = rng.choice(len(P1), SAFETY_CAP, replace=False)
            sel.sort()
            P1, P2, D12 = P1[sel], P2[sel], D12[sel]

        keep = clean_interior_mask(lbl, P1, P2, D12)
        P1, P2, D12 = P1[keep], P2[keep], D12[keep]
        if stype == "loose" and len(P1) > 4 * cap:
            sel = rng.choice(len(P1), 4 * cap, replace=False)
            sel.sort()
            P1, P2, D12 = P1[sel], P2[sel], D12[sel]
        if stype == "tight":
            diag["clean"] = np.histogram(D12, bins=BINS)[0]
        if len(P1) == 0:
            continue

        keep = local_two_sheet_mask(lbl, P1, P2, D12)
        if log_rejected and not keep.all():
            for ri in np.flatnonzero(~keep):
                rrow = [case_id, stype, *P1[ri], *P2[ri],
                        round(float(D12[ri]), 3)]
                if gt_instance is not None:
                    g1 = int(gt_instance[tuple(P1[ri])])
                    g2 = int(gt_instance[tuple(P2[ri])])
                    rrow += [g1, g2, int(g1 != g2)]
                rejected.append(rrow)
        P1, P2, D12 = P1[keep], P2[keep], D12[keep]
        if stype == "tight":
            diag["ccpass"] = np.histogram(D12, bins=BINS)[0]
        if len(P1) == 0:
            continue

        keep = thin_spatial(P1, P2, sep)
        P1, P2, D12 = P1[keep], P2[keep], D12[keep]
        if len(P1) > cap:
            sel = rng.choice(len(P1), cap, replace=False)
            sel.sort()
            P1, P2, D12 = P1[sel], P2[sel], D12[sel]
        diag[stype] = len(P1)
        if len(P1) == 0:
            continue

        coords, slices, dists = build_profiles(P1.astype(float), P2.astype(float), D12)
        mprof = {m: ndi.map_coordinates(probs[m].astype(np.float32), coords, order=1)
                 for m in model_names}
        xprof = None
        if stype == "tight" and prev_probs is not None:
            xprof = {m: ndi.map_coordinates(prev_probs[m].astype(np.float32),
                                            coords, order=1) for m in model_names}

        for si in range(len(P1)):
            a, b = slices[si]
            s = dists[si]
            d = D12[si]
            row = [case_id, stype, *P1[si], *P2[si], round(float(d), 3)]
            for m in model_names:
                e1, e2, dip, mx, pks = site_stats(mprof[m][a:b], s, d)
                row += [round(e1, 4), round(e2, 4), round(dip, 4), round(mx, 4), *pks]
            for m in model_names:
                if xprof is None:
                    row += ["", "", ""]
                else:
                    xe1, xe2, xdip = _end_dip(xprof[m][a:b], s, d)
                    row += [round(xe1, 4), round(xe2, 4), round(xdip, 4)]
            if gt_instance is not None:
                g1 = int(gt_instance[tuple(P1[si])])
                g2 = int(gt_instance[tuple(P2[si])])
                row += [g1, g2, int(g1 != g2)]
            rows.append(row)

    return rows, diag, rejected


def header_columns(model_names, with_gt=False):
    cols = ["case", "site_type", "i1", "j1", "k1", "i2", "j2", "k2", "d12"]
    for m in model_names:
        cols += [f"e1_{m}", f"e2_{m}", f"dip_{m}", f"mx_{m}",
                 f"pk4_{m}", f"pk5_{m}", f"pk6_{m}"]
    for m in model_names:
        cols += [f"xe1_{m}", f"xe2_{m}", f"xdip_{m}"]
    if with_gt:
        cols += ["gt_id1", "gt_id2", "gt_diff_sheet"]
    return cols


def rejected_columns(with_gt=False):
    cols = ["case", "site_type", "i1", "j1", "k1", "i2", "j2", "k2", "d12"]
    if with_gt:
        cols += ["gt_id1", "gt_id2", "gt_diff_sheet"]
    return cols


def diag_columns():
    b = [f"{BINS[i]:g}-{BINS[i + 1]:g}" for i in range(len(BINS) - 1)]
    return (["case", "n_pairs_tight_raw"]
            + [f"clean_{x}" for x in b]
            + [f"ccpass_{x}" for x in b]
            + ["n_tight_final", "n_loose_final"])


# ------------------------------------------------------------------- I/O -----
def _load_array(spec):
    """'path.npy', or 'path.npz:key', -> ndarray."""
    if spec.endswith(".npy"):
        return np.asarray(np.load(spec))
    if ":" in spec:
        path, key = spec.rsplit(":", 1)
        if path.endswith(".npz"):
            with np.load(path) as z:
                if key not in z:
                    raise KeyError(
                        f"key '{key}' not in {path}; keys={list(z.keys())}")
                return np.asarray(z[key])
    if spec.endswith(".npz"):
        with np.load(spec) as z:
            keys = list(z.keys())
        raise ValueError(
            f"{spec} is an .npz; specify a key as '{spec}:KEY'. keys={keys}")
    return np.asarray(np.load(spec))


def load_case(entry):
    """entry: dict with 'id', 'label', 'probs' {name: spec}, optional 'gt_instance'."""
    label = _load_array(entry["label"])
    probs = {name: np.asarray(_load_array(spec), dtype=np.float32)
             for name, spec in entry["probs"].items()}
    gt = _load_array(entry["gt_instance"]) if entry.get("gt_instance") else None
    return label, probs, gt


def _parse_kv(items):
    out = {}
    for it in items:
        if "=" not in it:
            raise SystemExit(f"--prob expects NAME=SPEC, got '{it}'")
        k, v = it.split("=", 1)
        out[k] = v
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Facing-pair (fusion-site) instrument, villa issue #191.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""examples:
  single case, two models:
    python facing_pairs.py --out results --case-id twin01 --label lbl.npy
        --prob mine=probA.npy --prob theirs=probB.npy

  single case from one npz bundle, with ground-truth instance ids:
    python facing_pairs.py --out results --case-id twin01
        --label case.npz:label --prob v0=case.npz:prob_v0
        --gt-instance case.npz:instances

  batch from a manifest (see README):
    python facing_pairs.py --out results --manifest cases.json --mismatch
""")
    ap.add_argument("--out", required=True, help="output directory")
    ap.add_argument("--manifest", help="JSON list of case entries (batch mode)")
    ap.add_argument("--case-id", help="single-case mode: case name")
    ap.add_argument("--label", help="single-case mode: label volume spec")
    ap.add_argument("--prob", action="append", default=[],
                    help="single-case mode: NAME=SPEC, repeatable")
    ap.add_argument("--gt-instance", help="single-case mode: GT instance volume spec")
    ap.add_argument("--log-rejected", action="store_true",
                    help="also write facing_pairs_cc_rejected.csv (step-3 rejects)")
    ap.add_argument("--no-loose", action="store_true",
                    help="skip the d12 in [8,14] distance-null sites")
    ap.add_argument("--mismatch", action="store_true",
                    help="batch mode: also evaluate on the previous case's probs")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--seed-mode", choices=["index", "caseid"], default="index",
                    help="'index' reproduces our Dataset059 run (rng=[seed, case_index]); "
                         "'caseid' is stable under reordering (rng=[seed, hash(id)])")
    ap.add_argument("--max-tight", type=int, default=MAX_TIGHT)
    ap.add_argument("--max-loose", type=int, default=MAX_LOOSE)
    ap.add_argument("--limit", type=int, help="process only the first N cases")
    args = ap.parse_args(argv)

    if args.manifest:
        with open(args.manifest) as fh:
            entries = json.load(fh)
        if not isinstance(entries, list):
            raise SystemExit("--manifest must contain a JSON list of case objects")
    else:
        if not (args.case_id and args.label and args.prob):
            raise SystemExit("single-case mode needs --case-id, --label and --prob")
        entries = [{"id": args.case_id, "label": args.label,
                    "probs": _parse_kv(args.prob), "gt_instance": args.gt_instance}]
    if args.limit:
        entries = entries[:args.limit]
    if not entries:
        raise SystemExit("no cases to process")

    model_names = list(entries[0]["probs"].keys())
    for e in entries:
        if list(e["probs"].keys()) != model_names:
            raise SystemExit(
                f"case '{e['id']}' has probs {list(e['probs'].keys())}, "
                f"expected {model_names} -- all cases must carry the same model set")
    with_gt = bool(entries[0].get("gt_instance"))

    os.makedirs(args.out, exist_ok=True)
    fh = open(os.path.join(args.out, "facing_pairs_sites.csv"), "w", newline="")
    w = csv.writer(fh)
    w.writerow(header_columns(model_names, with_gt))
    dh = open(os.path.join(args.out, "facing_pairs_case_diag.csv"), "w", newline="")
    dw = csv.writer(dh)
    dw.writerow(diag_columns())
    rh = rw = None
    if args.log_rejected:
        rh = open(os.path.join(args.out, "facing_pairs_cc_rejected.csv"),
                  "w", newline="")
        rw = csv.writer(rh)
        rw.writerow(rejected_columns(with_gt))

    prev_probs = None
    t0 = time.time()
    for ci, e in enumerate(entries):
        label, probs, gt = load_case(e)
        rng = make_rng(args.seed, ci, e["id"], args.seed_mode)
        rows, diag, rej = process_case(
            label, probs, case_id=e["id"], model_names=model_names, rng=rng,
            do_loose=not args.no_loose,
            prev_probs=prev_probs if args.mismatch else None,
            gt_instance=gt, max_tight=args.max_tight, max_loose=args.max_loose,
            log_rejected=args.log_rejected)
        w.writerows(rows)
        fh.flush()
        dw.writerow([e["id"], diag["raw"], *diag["clean"], *diag["ccpass"],
                     diag["tight"], diag["loose"]])
        dh.flush()
        if rw is not None:
            rw.writerows(rej)
            rh.flush()
        prev_probs = probs
        print(f"[{ci + 1}/{len(entries)}] {e['id']}: tight={diag['tight']} "
              f"loose={diag['loose']} ({time.time() - t0:.0f}s)", flush=True)

    fh.close()
    dh.close()
    if rh is not None:
        rh.close()
    print(f"DONE {time.time() - t0:.1f}s -> {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
