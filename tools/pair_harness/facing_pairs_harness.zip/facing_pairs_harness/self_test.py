"""self_test.py -- synthetic checks with known answers for facing_pairs.py.

No data files needed; runs in ~10 s on CPU. Exit 0 = PASS.

  A. Two parallel planes at a KNOWN gap of 4 voxels. Asserts: every tight site
     has d12 == 4.0 exactly and joins the two planes; sites are >= 3 voxels
     apart (thinning); no loose sites exist; GT instance columns disagree at
     every site; a two-peaked probability map reads 100% SPLIT and a slab map
     reads 100% FUSED at t=0.5 (peak counts 2 vs 1); byte-identical rows on a
     re-run (determinism).
  B. Distance null: a plane pair at gap 10 is picked up by the LOOSE stage
     (every loose site d12 == 10.0) and even a generous blur leaves a deep dip
     there -- fusion must collapse at loose distances.
  C. CC-guard: two planes at gap 3 joined by a wall at y=32. The step-3 guard
     must reject exactly the pairs whose local window reaches the wall
     (|y - 32| <= 5), log them per d12 bin, keep the far-from-wall pairs, and
     --log-rejected must expose each rejected pair with GT ids showing the two
     endpoints really are different sheets (gt_diff_sheet == 1).
"""
from __future__ import annotations

import sys

import numpy as np
from scipy import ndimage as ndi

import facing_pairs as fp

N = 64
T = 0.5


def norm_blur(vol, sigma):
    p = ndi.gaussian_filter(vol.astype(np.float32), sigma)
    return (p / max(p.max(), 1e-6)).astype(np.float32)


def run(label, probs, gt=None, log_rejected=False, seed_index=0):
    rng = np.random.default_rng([42, seed_index])
    return fp.process_case(label, probs, case_id="selftest",
                           model_names=list(probs), rng=rng,
                           gt_instance=gt, log_rejected=log_rejected)


def cols(models, with_gt):
    h = fp.header_columns(models, with_gt)
    return {c: i for i, c in enumerate(h)}


def test_A():
    lbl = np.zeros((N, N, N), np.uint8)
    lbl[30, 10:54, 10:54] = 1
    lbl[34, 10:54, 10:54] = 1
    gt = np.zeros((N, N, N), np.int32)
    gt[30, 10:54, 10:54] = 1
    gt[34, 10:54, 10:54] = 2

    slab = np.zeros_like(lbl)
    slab[30:35, 10:54, 10:54] = 1
    probs = {"split": norm_blur(lbl, 0.8), "fused": norm_blur(slab, 0.8)}

    rows, diag, rej = run(lbl, probs, gt=gt)
    rows2, _, _ = run(lbl, probs, gt=gt)
    assert rows == rows2, "A: not deterministic across re-runs"
    assert rej == [], "A: rejected list must be empty when log_rejected=False"

    c = cols(["split", "fused"], with_gt=True)
    tight = [r for r in rows if r[c["site_type"]] == "tight"]
    loose = [r for r in rows if r[c["site_type"]] == "loose"]
    assert len(tight) > 0, "A: no tight sites found"
    assert len(loose) == 0, f"A: unexpected loose sites ({len(loose)})"
    assert len(tight) <= fp.MAX_TIGHT

    for r in tight:
        assert r[c["d12"]] == 4.0, f"A: d12 {r[c['d12']]} != 4.0"
        assert {r[c["i1"]], r[c["i2"]]} == {30, 34}, "A: site not plane-to-plane"
        assert r[c["gt_id1"]] != r[c["gt_id2"]] and r[c["gt_diff_sheet"]] == 1

    mids = np.array([[(r[c["i1"]] + r[c["i2"]]) / 2,
                      (r[c["j1"]] + r[c["j2"]]) / 2,
                      (r[c["k1"]] + r[c["k2"]]) / 2] for r in tight])
    d = np.linalg.norm(mids[:, None] - mids[None, :], axis=2)
    np.fill_diagonal(d, np.inf)
    assert d.min() >= 3.0, f"A: thinning violated, min sep {d.min():.2f}"

    for name, want_fused, want_pk in (("split", False, 2), ("fused", True, 1)):
        det = fus = 0
        for r in tight:
            e1, e2, dip = r[c[f"e1_{name}"]], r[c[f"e2_{name}"]], r[c[f"dip_{name}"]]
            assert r[c[f"pk5_{name}"]] == want_pk, \
                f"A: {name} pk5={r[c[f'pk5_{name}']]} != {want_pk}"
            if e1 >= T and e2 >= T:
                det += 1
                fus += dip >= T
        assert det == len(tight), f"A: {name} not detected at every site"
        frac = fus / det
        assert frac == (1.0 if want_fused else 0.0), \
            f"A: {name} fused fraction {frac} unexpected"
    print(f"  A PASS: {len(tight)} tight sites, d12==4.0, split=0% fused, "
          f"slab=100% fused, GT columns correct, deterministic")


def test_B():
    lbl = np.zeros((N, N, N), np.uint8)
    lbl[20, 10:54, 10:54] = 1
    lbl[24, 10:54, 10:54] = 1     # tight pair, gap 4
    lbl[40, 10:54, 10:54] = 1
    lbl[50, 10:54, 10:54] = 1     # loose pair, gap 10
    probs = {"m": norm_blur(lbl, 1.0)}

    rows, diag, _ = run(lbl, probs)
    c = cols(["m"], with_gt=False)
    loose = [r for r in rows if r[c["site_type"]] == "loose"]
    assert len(loose) > 0, "B: no loose sites found"
    assert len(loose) <= fp.MAX_LOOSE
    for r in loose:
        assert r[c["d12"]] == 10.0, f"B: loose d12 {r[c['d12']]} != 10.0"
        assert {r[c["i1"]], r[c["i2"]]} == {40, 50}
        assert r[c["e1_m"]] >= T and r[c["e2_m"]] >= T, "B: ends not detected"
        assert r[c["dip_m"]] < 0.2, f"B: loose dip {r[c['dip_m']]} not collapsed"
    assert any(r[c["site_type"]] == "tight" for r in rows), "B: tight pair missed"
    print(f"  B PASS: {len(loose)} loose sites, d12==10.0, "
          f"max loose dip {max(r[c['dip_m']] for r in loose):.3f} < 0.2")


def test_C():
    lbl = np.zeros((N, N, N), np.uint8)
    lbl[44, 8:56, 8:56] = 1
    lbl[47, 8:56, 8:56] = 1
    lbl[45:47, 32, 8:56] = 1      # wall joins the planes at y=32
    gt = np.zeros((N, N, N), np.int32)
    gt[44, 8:56, 8:56] = 1
    gt[47, 8:56, 8:56] = 2
    gt[45:47, 32, 8:56] = 1
    probs = {"m": norm_blur(lbl, 1.0)}

    rows, diag, rej = run(lbl, probs, gt=gt, log_rejected=True)
    c = cols(["m"], with_gt=True)
    # d12 = 3.0 falls in histogram bin [3,4): index 1 of BINS [2,3,4,5,6.01]
    n_clean, n_ccpass = int(diag["clean"][1]), int(diag["ccpass"][1])
    assert n_clean > n_ccpass > 0, \
        f"C: expected partial CC-guard rejection, clean={n_clean} ccpass={n_ccpass}"
    assert len(rej) == sum(diag["clean"]) - sum(diag["ccpass"]), \
        "C: rejected log length != clean - ccpass"

    rc = {col: i for i, col in enumerate(fp.rejected_columns(with_gt=True))}
    for r in rej:
        assert r[rc["d12"]] == 3.0
        assert abs(r[rc["j1"]] - 32) <= 6, \
            f"C: rejected pair far from wall (j1={r[rc['j1']]})"
        assert r[rc["gt_id1"]] != r[rc["gt_id2"]] and r[rc["gt_diff_sheet"]] == 1, \
            "C: GT must show the rejected pair as two different sheets"
    tight = [r for r in rows if r[c["site_type"]] == "tight"]
    assert len(tight) > 0, "C: far-from-wall pairs should survive"
    for r in tight:
        assert abs(r[c["j1"]] - 32) > 5, \
            f"C: near-wall pair survived (j1={r[c['j1']]})"
    print(f"  C PASS: bin 3-4 clean={n_clean} ccpass={n_ccpass}, "
          f"{len(rej)} rejects logged, all near wall, all gt_diff_sheet==1; "
          f"{len(tight)} far-from-wall sites kept")


def main():
    for t in (test_A, test_B, test_C):
        t()
    print("SELF-TEST PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
