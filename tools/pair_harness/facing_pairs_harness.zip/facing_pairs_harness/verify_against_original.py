"""verify_against_original.py -- prove facing_pairs.py == the original extractor.

Runs BOTH implementations on the same synthetic volumes and asserts the output
rows are identical, cell for cell:

  original   experiments/trackA/panel/fusion/extract_fusion_sites.py
             (the script that produced the Dataset059 numbers in villa #191)
  port       facing_pairs.py (this package)

Method
------
1. Build N synthetic cubic cases (64^3) as <case>.npz with keys label,
   prob_v0..prob_v3 -- the exact layout the original consumes. The geometry is
   chosen to exercise every pipeline stage: a tight plane pair (gap 4), a
   tight merged pair with a connecting wall (gap 3; the wall forces step-3
   CC-guard rejections near it and step-2 interior rejections on it), and a
   loose plane pair (gap 10). Probability maps are per-model blurs of the
   label plus seeded noise, so e1/e2/dip/peak columns take varied values.
2. Copy the original script byte-for-byte into a scratch dir (never touching
   its home), import the copy, monkeypatch its module-level DATA/OUT paths to
   scratch, and call its main().
3. Run facing_pairs.py CLI on the same npz files via a manifest with the same
   model names, seed 42, seed-mode index, --mismatch (the original always
   computes the mismatch columns).
4. Compare fusion_sites.csv vs facing_pairs_sites.csv and fusion_case_diag.csv
   vs facing_pairs_case_diag.csv as parsed CSV: identical header, identical
   row count, identical cells (exact string equality -- both scripts round
   identically, so no tolerance is needed or used).
5. Require the run to have been non-trivial: raw candidates > 0, step-2 and
   step-3 rejections both > 0, tight and loose sites both > 0, mismatch
   columns populated from case 2 on.

Writes verify_report.json (sha256 of the original, funnel counts, verdict)
and exits 0 on PASS, 1 on FAIL.

usage:
  python verify_against_original.py --original PATH/TO/extract_fusion_sites.py
      [--workdir DIR] [--cases 3]
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import os
import shutil
import sys
import tempfile

import numpy as np
from scipy import ndimage as ndi

MODELS = ["v0", "v1", "v2", "v3"]
N = 64  # cubic side; the original assumes cubic volumes


# ---------------------------------------------------------------- synthesis --
def make_case(seed):
    """64^3 label volume + 4 probability maps, deterministic in `seed`."""
    rng = np.random.default_rng(seed)
    lbl = np.zeros((N, N, N), np.uint8)
    # tight pair, gap 4 (d12 = 4.0)
    lbl[28, 8:56, 8:56] = 1
    lbl[32, 8:56, 8:56] = 1
    # loose pair, gap 10 (d12 = 10.0)
    lbl[10, 8:56, 8:56] = 1
    lbl[20, 8:56, 8:56] = 1
    # merged pair, gap 3, joined by a wall at y=32 -> step-2 rejections on the
    # wall line, step-3 CC-guard rejections within a window radius of it
    lbl[44, 8:56, 8:56] = 1
    lbl[47, 8:56, 8:56] = 1
    lbl[45:47, 32, 8:56] = 1

    f = lbl.astype(np.float32)
    probs = {}
    for mi, m in enumerate(MODELS):
        sigma = (0.9, 2.2, 1.2, 1.7)[mi]
        p = ndi.gaussian_filter(f, sigma)
        p = p / max(p.max(), 1e-6)
        noise = ndi.gaussian_filter(rng.normal(0.0, 0.6, lbl.shape), 1.5)
        p = np.clip(p + 0.25 * noise.astype(np.float32), 0.0, 1.0)
        probs[m] = p.astype(np.float16)  # same dtype as the real probmap npzs
    return lbl, probs


# -------------------------------------------------------------------- helpers
def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def read_csv(path):
    with open(path, newline="") as fh:
        return list(csv.reader(fh))


def compare(name, a, b, report):
    ok = True
    if a[0] != b[0]:
        print(f"FAIL {name}: headers differ\n  orig: {a[0]}\n  port: {b[0]}")
        ok = False
    if len(a) != len(b):
        print(f"FAIL {name}: row counts differ orig={len(a)} port={len(b)}")
        ok = False
    if ok:
        for i, (ra, rb) in enumerate(zip(a, b)):
            if ra != rb:
                print(f"FAIL {name}: first differing row {i}:\n  orig: {ra}\n  port: {rb}")
                ok = False
                break
    report[name] = {"rows_orig": len(a) - 1, "rows_port": len(b) - 1,
                    "identical": ok}
    return ok


def main():
    ap = argparse.ArgumentParser()
    here = os.path.dirname(os.path.abspath(__file__))
    ap.add_argument("--original", default=os.path.join(here, "original",
                                                       "extract_fusion_sites.py"),
                    help="path to the original extract_fusion_sites.py")
    ap.add_argument("--workdir", default=None,
                    help="scratch dir (default: a fresh temp dir)")
    ap.add_argument("--cases", type=int, default=3)
    args = ap.parse_args()

    work = args.workdir or tempfile.mkdtemp(prefix="fp_verify_")
    data = os.path.join(work, "data")
    out_o = os.path.join(work, "out_original")
    out_p = os.path.join(work, "out_port")
    for d in (data, out_o, out_p):
        os.makedirs(d, exist_ok=True)

    with open(args.original, "rb") as fh:
        blob = fh.read()
    sha = hashlib.sha256(blob).hexdigest()
    orig_copy = os.path.join(work, "extract_fusion_sites_copy.py")
    with open(orig_copy, "wb") as fh:
        fh.write(blob)

    # 1. synthetic cases
    manifest = []
    for ci in range(args.cases):
        cid = f"synth{ci:02d}"
        lbl, probs = make_case(1000 + ci)
        npz = os.path.join(data, f"{cid}.npz")
        np.savez_compressed(npz, label=lbl,
                            **{f"prob_{m}": probs[m] for m in MODELS})
        manifest.append({"id": cid, "label": f"{npz}:label",
                         "probs": {m: f"{npz}:prob_{m}" for m in MODELS}})

    # 2. original, sandboxed: import the COPY, repoint DATA/OUT to scratch
    orig = load_module(orig_copy, "extract_fusion_sites_copy")
    orig.DATA = data
    orig.OUT = out_o
    assert orig.OUT == out_o and orig.DATA == data
    argv = sys.argv
    sys.argv = ["extract_fusion_sites_copy.py"]
    try:
        orig.main()
    finally:
        sys.argv = argv

    # 3. the port, via its real CLI path
    man_path = os.path.join(work, "manifest.json")
    with open(man_path, "w") as fh:
        json.dump(manifest, fh)
    fp = load_module(os.path.join(here, "facing_pairs.py"), "facing_pairs_v")
    rc = fp.main(["--out", out_p, "--manifest", man_path, "--mismatch",
                  "--seed", "42", "--seed-mode", "index"])
    if rc != 0:
        print("FAIL: facing_pairs.py returned nonzero")
        return 1

    # 4. compare
    report = {"original_path": os.path.abspath(args.original),
              "original_sha256": sha, "cases": args.cases,
              "numpy": np.__version__,
              "scipy": __import__("scipy").__version__,
              "python": sys.version.split()[0]}
    ok = compare("sites", read_csv(os.path.join(out_o, "fusion_sites.csv")),
                 read_csv(os.path.join(out_p, "facing_pairs_sites.csv")), report)
    ok &= compare("diag", read_csv(os.path.join(out_o, "fusion_case_diag.csv")),
                  read_csv(os.path.join(out_p, "facing_pairs_case_diag.csv")),
                  report)

    # 5. the run must have exercised every stage
    diag = read_csv(os.path.join(out_o, "fusion_case_diag.csv"))
    hdr = diag[0]
    tot = {h: sum(int(r[i]) for r in diag[1:]) for i, h in enumerate(hdr)
           if h != "case"}
    clean = sum(v for h, v in tot.items() if h.startswith("clean_"))
    ccpass = sum(v for h, v in tot.items() if h.startswith("ccpass_"))
    checks = {
        "raw_candidates>0": tot["n_pairs_tight_raw"] > 0,
        "step2_rejections>0": tot["n_pairs_tight_raw"] > clean,
        "step3_rejections>0": clean > ccpass,
        "tight_sites>0": tot["n_tight_final"] > 0,
        "loose_sites>0": tot["n_loose_final"] > 0,
    }
    sites = read_csv(os.path.join(out_o, "fusion_sites.csv"))
    xcol = sites[0].index("xe1_v0")
    ccol = sites[0].index("case")
    checks["mismatch_blank_case1"] = all(
        r[xcol] == "" for r in sites[1:] if r[ccol] == "synth00")
    checks["mismatch_filled_case2+"] = any(
        r[xcol] != "" for r in sites[1:] if r[ccol] != "synth00")
    for k, v in checks.items():
        if not v:
            print(f"FAIL coverage check: {k}")
            ok = False
    report["funnel_totals"] = tot
    report["coverage_checks"] = checks
    report["verdict"] = "PASS" if ok else "FAIL"

    with open(os.path.join(here, "verify_report.json"), "w") as fh:
        json.dump(report, fh, indent=2)
    print(json.dumps(report, indent=2))
    print("PASS: outputs identical" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
