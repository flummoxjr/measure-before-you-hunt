"""Fusion-site extraction (LENS=fusion, mirrors villa issue #191 instrument).

At sites where two label sheets pass within 6 voxels (distance between facing
surface voxels of the two sheets), walk the straight line between the two sheet
points in each model's probability map and record: peak height at each end,
minimum in the gap interior (the "dip"), max along the profile, and number of
local prob peaks (height>=t, prominence>=0.05) at t=0.4/0.5/0.6.

Site definition pipeline (all deterministic, seed 42):
  1. reflect-pair candidates from EDT nearest-indices (background voxel g, nearest
     label p1, nearest label to 2g-p1 = p2; opposite sides: cos<-0.3), deduped.
  2. clean interior: no label voxel strictly between the two sheet points.
  3. local two-sheet guard: p1,p2 in DIFFERENT 26-connected label components
     within a window of radius max(4, ceil(1.5*d12)) around the midpoint.
     Rejection counts per d12 bin are logged (labels merging tight contacts).
  4. spatial thinning: greedy, midpoints >= 3 voxels apart (4 for loose).
  5. seeded cap: 300 tight / 100 loose per case, rng = default_rng([42, case_idx]).

Controls extracted alongside:
  - "loose" sites (d12 in [8,14]) -- distance null: fusion should collapse.
  - mismatch control: same tight-site coordinates evaluated on the PREVIOUS
    case's probability maps (shuffle null; first case has no value).

Outputs (append-per-case so partial runs survive):
  fusion_sites.csv     one row per site
  fusion_case_diag.csv per-case funnel counts incl. CC-guard rejections by d12 bin
"""
import argparse, csv, os, time
import numpy as np
from scipy import ndimage as ndi
from scipy.signal import find_peaks

DATA = r"D:\vesuvius-data\trackA_probmaps"
OUT = r"C:\Users\benbl\Desktop\Vsuvious\experiments\trackA\panel\fusion"
MODELS = ["v0", "v1", "v2", "v3"]
STEP = 0.25
EXT = 1.0
MAX_TIGHT = 300
MAX_LOOSE = 100
BORDER = 5
PEAK_PROM = 0.05
ST26 = ndi.generate_binary_structure(3, 3)
BINS = [2, 3, 4, 5, 6.01]           # tight d12 bins for diagnostics

def candidate_pairs(lbl, edt, inds, edtlo, edthi, dmin, dmax):
    bg = lbl == 0
    cand = bg & (edt >= edtlo) & (edt <= edthi)
    cand[:BORDER] = cand[-BORDER:] = False
    cand[:, :BORDER] = cand[:, -BORDER:] = False
    cand[:, :, :BORDER] = cand[:, :, -BORDER:] = False
    g = np.argwhere(cand)
    if len(g) == 0:
        return np.zeros((0, 3), int), np.zeros((0, 3), int), np.zeros(0)
    p1 = inds[:, g[:, 0], g[:, 1], g[:, 2]].T.astype(np.int64)
    q = 2 * g - p1
    ok = np.all((q >= 0) & (q < lbl.shape[0]), axis=1)
    g, p1, q = g[ok], p1[ok], q[ok]
    p2 = inds[:, q[:, 0], q[:, 1], q[:, 2]].T.astype(np.int64)
    dv = (p2 - p1).astype(float)
    d12 = np.linalg.norm(dv, axis=1)
    v1 = (p1 - g).astype(float); v2 = (p2 - g).astype(float)
    n1 = np.linalg.norm(v1, axis=1); n2 = np.linalg.norm(v2, axis=1)
    cos = (v1 * v2).sum(1) / np.maximum(n1 * n2, 1e-9)
    ok = (d12 >= dmin) & (d12 <= dmax) & (cos < -0.3)
    p1, p2, d12 = p1[ok], p2[ok], d12[ok]
    if len(p1) == 0:
        return p1, p2, d12
    ok = (np.all((p1 >= BORDER) & (p1 < lbl.shape[0] - BORDER), axis=1) &
          np.all((p2 >= BORDER) & (p2 < lbl.shape[0] - BORDER), axis=1))
    p1, p2, d12 = p1[ok], p2[ok], d12[ok]
    if len(p1) == 0:
        return p1, p2, d12
    n3 = lbl.shape[0] ** 3
    f1 = np.ravel_multi_index(p1.T, lbl.shape)
    f2 = np.ravel_multi_index(p2.T, lbl.shape)
    key = np.minimum(f1, f2) * n3 + np.maximum(f1, f2)
    _, idx = np.unique(key, return_index=True)
    idx = np.sort(idx)
    return p1[idx], p2[idx], d12[idx]

def build_profiles(P1, P2, D12):
    coords, slices, dists = [], [], []
    off = 0
    for a, b, d in zip(P1, P2, D12):
        u = (b - a) / d
        s = np.arange(-EXT, d + EXT + 1e-9, STEP)
        coords.append(a[None, :] + s[:, None] * u[None, :])
        slices.append((off, off + len(s)))
        dists.append(s)
        off += len(s)
    return np.concatenate(coords).T, slices, dists

def clean_interior_mask(lbl, P1, P2, D12):
    coords, slices, dists = build_profiles(P1.astype(float), P2.astype(float), D12)
    lprof = ndi.map_coordinates(lbl.astype(np.float32), coords, order=0)
    keep = np.zeros(len(P1), bool)
    for i, ((a, b), s, d) in enumerate(zip(slices, dists, D12)):
        interior = (s >= 0.75) & (s <= d - 0.75)
        keep[i] = (not interior.any()) or lprof[a:b][interior].max() == 0
    return keep

def local_two_sheet_mask(lbl, P1, P2, D12):
    keep = np.zeros(len(P1), bool)
    for i in range(len(P1)):
        R = int(max(4, np.ceil(1.5 * D12[i])))
        m = ((P1[i] + P2[i]) / 2).round().astype(int)
        lo = np.maximum(m - R, 0); hi = np.minimum(m + R + 1, lbl.shape[0])
        cc, _ = ndi.label(lbl[lo[0]:hi[0], lo[1]:hi[1], lo[2]:hi[2]], structure=ST26)
        a = cc[tuple(P1[i] - lo)]; b = cc[tuple(P2[i] - lo)]
        keep[i] = (a != b) and a > 0 and b > 0
    return keep

def thin_spatial(P1, P2, min_sep):
    """Greedy thinning on midpoints, deterministic (lexicographic order)."""
    M = (P1 + P2) / 2.0
    order = np.lexsort((M[:, 2], M[:, 1], M[:, 0]))
    kept, kept_pts = [], []
    for i in order:
        p = M[i]
        if all(np.linalg.norm(p - q) >= min_sep for q in kept_pts):
            kept.append(i); kept_pts.append(p)
    return np.sort(np.array(kept, int))

def site_stats(prof, s, d12):
    margin = min(1.0, max(0.6, (d12 - 0.5) / 2.0))
    m1 = s <= 0.75
    m2 = s >= d12 - 0.75
    mi = (s >= margin) & (s <= d12 - margin)
    e1 = float(prof[m1].max()); e2 = float(prof[m2].max())
    dip = float(prof[mi].min()) if mi.any() else float(min(e1, e2))
    mx = float(prof.max())
    pks = []
    for t in (0.4, 0.5, 0.6):
        p, _ = find_peaks(prof, height=t, prominence=PEAK_PROM)
        n = len(p)
        if n == 0 and mx >= t:
            n = 1        # broad plateau above t with no interior structure
        pks.append(n)
    return e1, e2, dip, mx, pks

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    files = sorted(f for f in os.listdir(DATA) if f.endswith(".npz"))
    if args.limit:
        files = files[: args.limit]

    cols = ["case", "site_type", "i1", "j1", "k1", "i2", "j2", "k2", "d12"]
    for m in MODELS:
        cols += [f"e1_{m}", f"e2_{m}", f"dip_{m}", f"mx_{m}",
                 f"pk4_{m}", f"pk5_{m}", f"pk6_{m}"]
    for m in MODELS:
        cols += [f"xe1_{m}", f"xe2_{m}", f"xdip_{m}"]
    fh = open(os.path.join(OUT, "fusion_sites.csv"), "w", newline="")
    w = csv.writer(fh); w.writerow(cols)

    dh = open(os.path.join(OUT, "fusion_case_diag.csv"), "w", newline="")
    dw = csv.writer(dh)
    dbins = [f"{BINS[i]:g}-{BINS[i+1]:g}" for i in range(len(BINS) - 1)]
    dw.writerow(["case", "n_pairs_tight_raw"]
                + [f"clean_{b}" for b in dbins]
                + [f"ccpass_{b}" for b in dbins]
                + ["n_tight_final", "n_loose_final"])

    prev_probs = None
    t0 = time.time()
    for ci, fn in enumerate(files):
        case = fn[:-4]
        z = np.load(os.path.join(DATA, fn))
        lbl = z["label"] > 0
        probs = {m: z[f"prob_{m}"].astype(np.float32) for m in MODELS}
        edt, inds = ndi.distance_transform_edt(~lbl, return_indices=True)
        rng = np.random.default_rng([42, ci])
        diag = {"raw": 0, "clean": np.zeros(4, int), "ccpass": np.zeros(4, int),
                "tight": 0, "loose": 0}
        rows = []
        for stype, (elo, ehi, dmin, dmax, cap, sep) in {
            "tight": (0.9, 3.05, 2.0, 6.0, MAX_TIGHT, 3.0),
            "loose": (3.9, 7.05, 8.0, 14.0, MAX_LOOSE, 4.0),
        }.items():
            P1, P2, D12 = candidate_pairs(lbl, edt, inds, elo, ehi, dmin, dmax)
            if stype == "tight":
                diag["raw"] = len(P1)
            if len(P1) == 0:
                continue
            if len(P1) > 60000:      # safety cap before per-pair checks
                sel = rng.choice(len(P1), 60000, replace=False); sel.sort()
                P1, P2, D12 = P1[sel], P2[sel], D12[sel]
            keep = clean_interior_mask(lbl, P1, P2, D12)
            P1, P2, D12 = P1[keep], P2[keep], D12[keep]
            if stype == "loose" and len(P1) > 4 * cap:
                sel = rng.choice(len(P1), 4 * cap, replace=False); sel.sort()
                P1, P2, D12 = P1[sel], P2[sel], D12[sel]
            if stype == "tight":
                diag["clean"] = np.histogram(D12, bins=BINS)[0]
            if len(P1) == 0:
                continue
            keep = local_two_sheet_mask(lbl, P1, P2, D12)
            P1, P2, D12 = P1[keep], P2[keep], D12[keep]
            if stype == "tight":
                diag["ccpass"] = np.histogram(D12, bins=BINS)[0]
            if len(P1) == 0:
                continue
            keep = thin_spatial(P1, P2, sep)
            P1, P2, D12 = P1[keep], P2[keep], D12[keep]
            if len(P1) > cap:
                sel = rng.choice(len(P1), cap, replace=False); sel.sort()
                P1, P2, D12 = P1[sel], P2[sel], D12[sel]
            diag[stype] = len(P1)

            coords, slices, dists = build_profiles(P1.astype(float), P2.astype(float), D12)
            mprof = {m: ndi.map_coordinates(probs[m], coords, order=1) for m in MODELS}
            xprof = ({m: ndi.map_coordinates(prev_probs[m], coords, order=1) for m in MODELS}
                     if (stype == "tight" and prev_probs is not None) else None)
            for si in range(len(P1)):
                a, b = slices[si]; s = dists[si]; d = D12[si]
                row = [case, stype, *P1[si], *P2[si], round(float(d), 3)]
                for m in MODELS:
                    e1, e2, dip, mx, pks = site_stats(mprof[m][a:b], s, d)
                    row += [round(e1, 4), round(e2, 4), round(dip, 4), round(mx, 4), *pks]
                for m in MODELS:
                    if xprof is None:
                        row += ["", "", ""]
                    else:
                        pr = xprof[m][a:b]
                        margin = min(1.0, max(0.6, (d - 0.5) / 2.0))
                        mi = (s >= margin) & (s <= d - margin)
                        xe1 = float(pr[s <= 0.75].max())
                        xe2 = float(pr[s >= d - 0.75].max())
                        xdip = float(pr[mi].min()) if mi.any() else min(xe1, xe2)
                        row += [round(xe1, 4), round(xe2, 4), round(xdip, 4)]
                rows.append(row)
        w.writerows(rows); fh.flush()
        dw.writerow([case, diag["raw"], *diag["clean"], *diag["ccpass"],
                     diag["tight"], diag["loose"]]); dh.flush()
        prev_probs = probs
        print(f"[{ci+1}/{len(files)}] {case}: tight={diag['tight']} loose={diag['loose']} "
              f"({time.time()-t0:.0f}s)", flush=True)
    fh.close(); dh.close()
    print("DONE", time.time() - t0)

if __name__ == "__main__":
    main()
